insert into bank_charges(id, bank_type, charges) values (1, 'public', 500.0);
insert into bank_charges(id, bank_type, charges) values (2, 'private', 550.0);